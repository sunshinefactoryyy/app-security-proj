module.exports = {
  mode: 'jit',
  prefix: 'tw-',
  content: ["./app/templates/**/*.html"],
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}