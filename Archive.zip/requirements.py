from os import system
system("pip3 install -r requirements.txt")